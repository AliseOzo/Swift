import UIKit

var str = "Hello, playground"
var ptr = "Hello, playground"
var otr = "Hello, playground"
var itr = "Hello, playground"
var utr = "Hello, playground"
var ytr = "Hello, playground"
